#ifndef GLOBVAR_H
#define GLOBVAR_H

#endif // GLOBVAR_H
